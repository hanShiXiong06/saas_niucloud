<template>


    详情页面


</template>

<script lang="ts" setup>

import { getTree } from "@/addon/phone_shop_price/api/recycle"
import { ref } from 'vue';


</script>

<style></style>